To test the code in visual studio, it is important to download the python packages available in the utilities folder in the github link.

Python packages: https://github.com/dalevens/OpenTitration/tree/main/Utilities

Download the python packages and unzip them into "TitrationAnalyzer\bin\Release" and/or "TitrationAnalyzer\bin\Debug" to be able to run the simulator when testing out the code.

Please report all errors and suggestions to opentitration@gmail.com

Enjoy!

Daniel Levenson, MSc.